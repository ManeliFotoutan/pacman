#include <iostream>
#include <conio.h>
#include <unistd.h>
#include <ctime>
#include <windows.h>

using namespace std;

const int BOARD_SIZE = 32;
char board[BOARD_SIZE][BOARD_SIZE];
int currRow = 3, currCol = 3;
int newRow, newCol;
int newRowGhost, newColGhost;
int newRowGhost2, newColGhost2;
int currRowGhost = 13, currColGhost = 13; 
int currRowGhost2 = 20, currColGhost2 = 29;
int mane[200][2];
int counter = 0,countermane=0;
int LoseCounter = 3;
int score = 10;
char initialGhostLetter = '.';
char initialGhostLetter2 = '.';


void Barier()
{
    for (int i = 0; i < BOARD_SIZE; i++)
    {
        for (int j = 0; j < BOARD_SIZE; j++)
        {
     if ((i == 2 && 3 <= j && j <= 25) || (i == 9 && 3 <= j && j <= 9))
                board[i][j] = '#';
     if ((i == 6 && 19 <= i && i <= 25) || (i == 6 && 19 <= j && j <= 25))
                board[i][j] = '#';
     if ((i == 4 && 3 <= j && j <= 5) || (i == 4 && 8 <= j && j <= 9))
                board[i][j] = '#';
     if ((i == 7 && 3 <= j && j <= 5) || (i == 7 && 5 <= j && j <= 10))
                board[i][j] = '#';
     if ((i == 13 && 3 <= j && j <= 25) || (i == 17 && 3 <= j && j <= 25))
                board[i][j] = '#';
     if ((j == 3 && 4 <= i && i <= 7) || (j == 3 && 10 <= i && i <= 11) || (j == 3 && 19 <= i && i <= 22))
                board[i][j] = '#';
     if ((j == 9 && 19 <= i && i <= 22)||(j == 9 && 24 <= i && i <= 27)||(j == 9 && 10 <= i && i <= 11)||(j == 9 && 4 <= i && i <= 7))
                board[i][j] = '#';
     if ((i == 19 && 3 <= j && j <= 5) || (i == 19 && 8 <= j && j <= 5) || (i == 19 && 20 <= j && j <= 25))
                board[i][j] = '#';
     if ((i == 22 && 3 <= j && j <= 10) || (i == 27 && 3 <= j && j <= 9))
                board[i][j] = '#';
     if ((j == 21 && i == 15) || (j == 28 && 21 <= i && i <= 24) || (j == 25 && 2 <= i && i <= 6))
                board[i][j] = '#';
     if ((j == 23 && i == 14) || (j == 23 && i == 16))
                board[i][j] = '#';
    if ((i == 20 && j == 18) || (i == 20 && j == 26))
                board[i][j] = '#';
    if ((j == 17 && 21 <= i && i <= 24) || (j == 19 && 4 <= i && i <= 6))
                board[i][j] = '#';
     if ((i == 25 && j == 19) || (i == 25 && j == 26))
                board[i][j] = '#';
     if ((i == 24 && j == 21) || (i == 24 && j == 25) || (i == 24 && 3 <= j && j <= 10))
                board[i][j] = '#';
        }
    }
}


void RandomBarier()
{
    int k;
    for (k = 0; k < 50; k++)
    {
        if ((mane[k][0] != 0) && (mane[k][1]!= BOARD_SIZE - 1) && (mane[k][1] != 0) && (mane[k][0]!= BOARD_SIZE - 1) && (mane[k][0] != 3 && mane[k][1] != 3))
            board[mane[k][0]][mane[k][1]] = '#';
            countermane++;
    }
}

void Random()
{
    srand((unsigned)time(0));
    for (int i = 0; i < 50; i++)
    {
        mane[i][0] = rand() % 32;
        mane[i][1] = rand() % 32;
    }
}

void InitializeBoard(){
    for (int i = 0; i < BOARD_SIZE; i++)
    {
        for (int j = 0; j < BOARD_SIZE; j++)
        {

            if (i == currRow && j == currCol)
            {
                board[i][j] = 'X';
            }

            else if (i == 5 && j == 0)
            {
                board[i][j] = '-';
            }
            else if (i == 5 && j == BOARD_SIZE - 1)
            {
                board[i][j] = '-';
            }
            else if (i == currRowGhost && j == currColGhost)
            {
                board[i][j] = 'G';
            }
            else if (i == currRowGhost2 && j == currColGhost2)
            {
                board[i][j] = 'K';
            }
            else if (i == 0 || j == 0 || i == BOARD_SIZE - 1 || j == BOARD_SIZE - 1)
            {
                board[i][j] = '#';
            }
         
            else
            {
                board[i][j] = '.';
                counter++;
            }

        }
    }
}

void set_cursor(int x = 0, int y = 0)
{
    HANDLE handle;
    COORD coordinates;
    handle = GetStdHandle(STD_OUTPUT_HANDLE);
    coordinates.X = x;
    coordinates.Y = y;
    SetConsoleCursorPosition(handle, coordinates);
}

void printBoard()
{
    set_cursor(0, 0);
    for (int i = 0; i < BOARD_SIZE; i++)
    {
        for (int j = 0; j < BOARD_SIZE; j++)
        {
            if (board[i][j] == '.')
            {
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 0x8);
            }
            if ((board[i][j] == 'X') || (board[i][j] == '-'))
            {
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 0x6);
            }
            if (board[i][j] == '#')
            {
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 0x5);
            }
            if (board[i][j] == 'G')
            {
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 0x2);
            }
            if (board[i][j] == 'K')
            {
                HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
                SetConsoleTextAttribute(h, 0x2);
            }

            cout << board[i][j];
        }
        cout << endl;
    }
}

// void swap(char &first, char &second)
// {
//     char temp = first;
//     first = second;
//     second = temp;
// }

void move(char key)
{

    switch (key)
    {
    case 'w':
        newRow = currRow - 1;
        newCol = currCol;
        break;
    case 's':
        newRow = currRow + 1;
        newCol = currCol;
        break;
    case 'a':
        newRow = currRow;
        newCol = currCol - 1;
        break;
    case 'd':
        newRow = currRow;
        newCol = currCol + 1;
        break;
    default:
        newCol = currCol;
        newRow = currRow;
        break;
    }

    if (board[newRow][newCol] == '-')
    {
        if (newCol <= 0)
        {
            newCol = BOARD_SIZE - 2;
        }
        if (newCol == BOARD_SIZE - 1)
        {
            newCol = 0;
        }
        usleep(0.1 * 1000000);
    }

    if (board[newRow][newCol] == '#')
    {
        {
            newRow = currRow;
            newCol = currCol;
        }
    }

    if (board[newRow][newCol] == '.')
    {
        counter--;
        
        score += 10;
        cout << score << endl;
    }

    board[currRow][currCol] = ' ';
    currRow = newRow;
    currCol = newCol;
    board[currRow][currCol] = 'X';

    usleep(0.3 * 1000000);
}

int finadDistance(int newGhostRow, int newGhostCol)
{
    int followRow = (newGhostRow - currRow > 0) ? (newGhostRow - currRow) : (currRow - newGhostRow);
    int followCol = (newGhostCol - currCol > 0) ? (newGhostCol - currCol) : (currCol - newGhostCol);
    return followRow + followCol;
}

void moveGhostRandomly()
{
    srand((unsigned)time(0));
    int r = rand() % 4;
    switch (r)
    {
    case 1:
        newColGhost = currColGhost + 1;
        newRowGhost = currRowGhost;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    case 2:
        newColGhost = currColGhost - 1;
        newRowGhost = currRowGhost;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    case 3:
        newColGhost = currColGhost;
        newRowGhost = currRowGhost + 1;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    case 4:
        newColGhost = currColGhost;
        newRowGhost = currRowGhost - 1;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    default:
        newColGhost = currColGhost;
        newRowGhost = currRowGhost;
    }
}




int finadDistance2(int newGhostRow2, int newGhostCol2)
{
    int followRow2 = (newGhostRow2 - currRow > 0) ? (newGhostRow2 - currRow) : (currRow - newGhostRow2);
    int followCol2 = (newGhostCol2 - currCol > 0) ? (newGhostCol2 - currCol) : (currCol - newGhostCol2);
    return followRow2 + followCol2;
}

void moveGhostRandomly2()
{
    srand((unsigned)time(0));
    int t = rand() % 4;
    switch (t)
    {
    case 1:
        newColGhost2 = currColGhost2 + 1;
        newRowGhost2 = currRowGhost2;
        if (board[newRowGhost2][newColGhost2] != '#')
            break;
    case 2:
        newColGhost2 = currColGhost2 - 1;
        newRowGhost2 = currRowGhost2;
        if (board[newRowGhost2][newColGhost2] != '#')
            break;
    case 3:
        newColGhost2 = currColGhost2;
        newRowGhost2 = currRowGhost2 + 1;
        if (board[newRowGhost2][newColGhost2] != '#')
            break;
    case 4:
        newColGhost2 = currColGhost2;
        newRowGhost2 = currRowGhost2 - 1;
        if (board[newRowGhost2][newColGhost2] != '#')
            break;
    default:
        newColGhost2 = currColGhost2;
        newRowGhost2 = currRowGhost2;
    }
}



void MoveGhostEasy()
{
    int minDistance2 = 100;
    int distance2;
    int currDistance2 = finadDistance(currRowGhost, currColGhost);
    if (currDistance2 < 5)
        moveGhostRandomly2();
    else
    {
        if (board[currRowGhost2 + 1][currColGhost2] != '#')
        {
            distance2 = finadDistance2(currRowGhost2 + 1, currColGhost2);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2;
                newRowGhost2 = currRowGhost2 + 1;
            }
        }
        if (board[currRowGhost2 - 1][currColGhost2] != '#')
        {
            distance2 = finadDistance2(currRowGhost2 - 1, currColGhost2);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2;
                newRowGhost2 = currRowGhost2 - 1;
            }
        }
        if (board[currRowGhost2][currColGhost2 + 1] != '#')
        {
            distance2 = finadDistance2(currColGhost2, currColGhost2 + 1);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2 + 1;
                newRowGhost2 = currRowGhost2;
            }
        }

        if (board[currRowGhost2][currColGhost2 - 1] != '#')
        {
            distance2 = finadDistance2(currColGhost2, currColGhost2 - 1);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2 - 1;
                newRowGhost2 = currRowGhost2;
            }
        }
    }

    board[currRowGhost2][currColGhost2] = initialGhostLetter2;
    if (board[newRowGhost2][newColGhost2] == 'G')
    {
        initialGhostLetter2 = initialGhostLetter;
    }
    else
    {
        initialGhostLetter2 = board[newRowGhost2][newColGhost2];
    }
    board[newRowGhost2][newColGhost2] = 'K';
    currColGhost2 = newColGhost2;
    currRowGhost2 = newRowGhost2;
}

int MoveGhostEasy2()
{
    srand((unsigned)time(0));
    int r = rand() % 4;
    switch (r)
    {
    case 1:
        newColGhost = currColGhost + 1;
        newRowGhost = currRowGhost;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    case 2:
        newColGhost = currColGhost - 1;
        newRowGhost = currRowGhost;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    case 3:
        newColGhost = currColGhost;
        newRowGhost = currRowGhost + 1;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    case 4:
        newColGhost = currColGhost;
        newRowGhost = currRowGhost - 1;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    default:
        newColGhost = currColGhost;
        newRowGhost = currRowGhost;
    }

    board[currRowGhost][currColGhost] = initialGhostLetter;
    if (newRowGhost == currRowGhost2 && newColGhost == currColGhost2)
    {
        initialGhostLetter = initialGhostLetter2;
    }
    else
    {
        initialGhostLetter = board[newRowGhost][newColGhost];
    }
    board[newRowGhost][newColGhost] = 'G';
    currColGhost = newColGhost;
    currRowGhost = newRowGhost;
}

int MoveGhostMedium()
{
    int minDistance2 = 100;
    int distance2;
    int currDistance2 = finadDistance(currRowGhost, currColGhost);
    if (currDistance2 < 4)
        moveGhostRandomly2();
    else
    {
        if (board[currRowGhost2 + 1][currColGhost2] != '#')
        {
            distance2 = finadDistance2(currRowGhost2 + 1, currColGhost2);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2;
                newRowGhost2 = currRowGhost2 + 1;
            }
        }
        if (board[currRowGhost2 - 1][currColGhost2] != '#')
        {
            distance2 = finadDistance2(currRowGhost2 - 1, currColGhost2);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2;
                newRowGhost2 = currRowGhost2 - 1;
            }
        }
        if (board[currRowGhost2][currColGhost2 + 1] != '#')
        {
            distance2 = finadDistance2(currColGhost2, currColGhost2 + 1);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2 + 1;
                newRowGhost2 = currRowGhost2;
            }
        }

        if (board[currRowGhost2][currColGhost2 - 1] != '#')
        {
            distance2 = finadDistance2(currColGhost2, currColGhost2 - 1);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2 - 1;
                newRowGhost2 = currRowGhost2;
            }
        }
    }

    board[currRowGhost2][currColGhost2] = initialGhostLetter2;
    if (board[newRowGhost2][newColGhost2] == 'G')
    {
        initialGhostLetter2 = initialGhostLetter;
    }
    else
    {
        initialGhostLetter2 = board[newRowGhost2][newColGhost2];
    }
    board[newRowGhost2][newColGhost2] = 'K';
    currColGhost2 = newColGhost2;
    currRowGhost2 = newRowGhost2;
}

int MoveGhostMedium2()
{
    srand((unsigned)time(0));
    int r = rand() % 4;
    switch (r)
    {
    case 1:
        newColGhost = currColGhost + 1;
        newRowGhost = currRowGhost;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    case 2:
        newColGhost = currColGhost - 1;
        newRowGhost = currRowGhost;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    case 3:
        newColGhost = currColGhost;
        newRowGhost = currRowGhost + 1;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    case 4:
        newColGhost = currColGhost;
        newRowGhost = currRowGhost - 1;
        if (board[newRowGhost][newColGhost] != '#')
            break;
    default:
        newColGhost = currColGhost;
        newRowGhost = currRowGhost;
    }

    board[currRowGhost][currColGhost] = initialGhostLetter;
    if (newRowGhost == currRowGhost2 && newColGhost == currColGhost2)
    {
        initialGhostLetter = initialGhostLetter2;
    }
    else
    {
        initialGhostLetter = board[newRowGhost][newColGhost];
    }
    board[newRowGhost][newColGhost] = 'G';
    currColGhost = newColGhost;
    currRowGhost = newRowGhost;
}

void MoveGhost()
{
    int minDistance = 100;
    int distance;
    int currDistance = finadDistance(currRowGhost, currColGhost);
    if (currDistance < 4)
        moveGhostRandomly();
    else
    {
        if (board[currRowGhost + 1][currColGhost] != '#')
        {
            distance = finadDistance(currRowGhost + 1, currColGhost);
            if (distance < minDistance)
            {
                minDistance = distance;
                newColGhost = currColGhost;
                newRowGhost = currRowGhost + 1;
            }
        }
        if (board[currRowGhost - 1][currColGhost] != '#')
        {
            distance = finadDistance(currRowGhost - 1, currColGhost);
            if (distance < minDistance)
            {
                minDistance = distance;
                newColGhost = currColGhost;
                newRowGhost = currRowGhost - 1;
            }
        }
        if (board[currRowGhost][currColGhost + 1] != '#')
        {
            distance = finadDistance(currRowGhost, currColGhost + 1);
            if (distance < minDistance)
            {
                minDistance = distance;
                newColGhost = currColGhost + 1;
                newRowGhost = currRowGhost;
            }
        }

        if (board[currRowGhost][currColGhost - 1] != '#')
        {
            distance = finadDistance(currRowGhost, currColGhost - 1);
            if (distance < minDistance)
            {
                minDistance = distance;
                newColGhost = currColGhost - 1;
                newRowGhost = currRowGhost;
            }
        }
    }

    board[currRowGhost][currColGhost] = initialGhostLetter;
    if (board[newRowGhost][newColGhost] == 'k')
    {
        initialGhostLetter = initialGhostLetter2;
    }
    else
    {
        initialGhostLetter = board[newRowGhost][newColGhost];
    }
    board[newRowGhost][newColGhost] = 'G';
    currColGhost = newColGhost;
    currRowGhost = newRowGhost;
}

void MoveGhost2()
{
    int minDistance2 = 100;
    int distance2;
    int currDistance2 = finadDistance(currRowGhost, currColGhost);
    if (currDistance2 < 4)
        moveGhostRandomly2();
    else
    {
        if (board[currRowGhost2 + 1][currColGhost2] != '#')
        {
            distance2 = finadDistance2(currRowGhost2 + 1, currColGhost2);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2;
                newRowGhost2 = currRowGhost2 + 1;
            }
        }
        if (board[currRowGhost2 - 1][currColGhost2] != '#')
        {
            distance2 = finadDistance2(currRowGhost2 - 1, currColGhost2);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2;
                newRowGhost2 = currRowGhost2 - 1;
            }
        }
        if (board[currRowGhost2][currColGhost2 + 1] != '#')
        {
            distance2 = finadDistance2(currColGhost2, currColGhost2 + 1);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2 + 1;
                newRowGhost2 = currRowGhost2;
            }
        }

        if (board[currRowGhost2][currColGhost2 - 1] != '#')
        {
            distance2 = finadDistance2(currColGhost2, currColGhost2 - 1);
            if (distance2 < minDistance2)
            {
                minDistance2 = distance2;
                newColGhost2 = currColGhost2 - 1;
                newRowGhost2 = currRowGhost2;
            }
        }
    }

    board[currRowGhost2][currColGhost2] = initialGhostLetter2;
    if (board[newRowGhost2][newColGhost2] == 'G')
    {
        initialGhostLetter2 = initialGhostLetter;
    }
    else
    {
        initialGhostLetter2 = board[newRowGhost2][newColGhost2];
    }
    board[newRowGhost2][newColGhost2] = 'K';
    currColGhost2 = newColGhost2;
    currRowGhost2 = newRowGhost2;
}

bool Win()
{
    if (counter == 0)
    {
        return true;
    }
    return false;
}

bool Lose()
{
    if ((currColGhost == currCol && currRowGhost == currRow) || (currColGhost2 == currCol && currRowGhost2 == currRow))
    {
        board[currRowGhost][currColGhost] = initialGhostLetter;
        initialGhostLetter = board[13][13];
        currRowGhost = 13;
        currColGhost = 13;

        board[currRowGhost2][currColGhost2] = initialGhostLetter2;
        initialGhostLetter2 = board[1][13];
        currRowGhost2 = 1;
        currColGhost2 = 13;

        LoseCounter--;
        currColGhost = 2;
        cout <<endl<< "Becareful!" << endl
             << "X:" << LoseCounter << endl;

        if (LoseCounter == 0)
        {
            return true;
        }
    }
    return false;
} 

int main()
{   
    int n;
    cout << "choose level:" << endl
         << "1:easy" << endl
         << "2:medium" << endl
         << "3:hard" << endl;
    cin >> n;
  
    char key;
    system("cls");

    Random();
    InitializeBoard();
    RandomBarier();
    Barier();
    while (true)
    {
        if (n == 3)
        {
            MoveGhost();
            MoveGhost2();
        }
        if (n == 2)
        {
            MoveGhostMedium();
            MoveGhostMedium2();
        }
        if (n == 1)
        {
            MoveGhostEasy();
            MoveGhostEasy2();
        }
        printBoard();
        if (kbhit())
        {
            key = getch();
        }
        if (Win())
        {
            cout << "You Win!" << endl
                 << "score:" << score<<endl;
            break;
        }
        if (kbhit())
        {
            key = getch();
        }
        if (Lose())
        {
            cout << "You Lose!" << endl
                 << "score:" << score<<endl;
            break;
        }

        move(key);
    }
}
